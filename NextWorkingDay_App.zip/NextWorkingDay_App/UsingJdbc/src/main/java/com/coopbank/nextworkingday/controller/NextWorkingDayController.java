package com.coopbank.nextworkingday.controller;


import com.coopbank.nextworkingday.model.NextWorkingDay;
import com.coopbank.nextworkingday.model.PublicHolidayDates;
import com.coopbank.nextworkingday.model.PublicHolidayRequest;
import com.coopbank.nextworkingday.repository.NextWorkingDayInterface;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


@RestController
@RequestMapping("/api")
public class NextWorkingDayController {

    @Autowired
    private NextWorkingDayInterface nextWorkingDayInterface;

    @GetMapping("/nextworkingday")
    public ResponseEntity<NextWorkingDay> getNextWorkingDay(@RequestParam(name = "dateInput", required = false) String dateInput) {
    	NextWorkingDay nextWorkingDay =  new NextWorkingDay();
    	try {
            // Check if dateInput is null or empty
            if (dateInput == null || dateInput.isEmpty()) {
                // Handle the case where dateInput is null (return default behavior or error message)
                // For now, we'll just return a default response with the current date
            	System.out.println("Got here......");
                Date currentDate = new Date();
              
                 nextWorkingDay = nextWorkingDayInterface.nextworkingday(formatDate(currentDate));
                 nextWorkingDay.setErrorcode("200");
             	nextWorkingDay.setErrormessge("The next Working date");
             	nextWorkingDay.setInputdate(dateInput);
                return new ResponseEntity<>(nextWorkingDay, HttpStatus.OK);
            } else {
                // Parse the dateInput if it's not null or empty
                Date inputDate = parseDate(dateInput);
              

                if (inputDate != null) {
                     nextWorkingDay = nextWorkingDayInterface.nextworkingday(formatDate(inputDate));
                    if (nextWorkingDay != null) {
                    	nextWorkingDay.setErrorcode("200");
                    	nextWorkingDay.setErrormessge("The next Working date");
                    	nextWorkingDay.setInputdate(dateInput);
                        return new ResponseEntity<>(nextWorkingDay, HttpStatus.OK);
                    } else {
                    	
                    	nextWorkingDay.setErrorcode("400");
                    	nextWorkingDay.setErrormessge("The after date is not a valid date");
                    	nextWorkingDay.setInputdate(dateInput);
                    	
                        return new ResponseEntity<>(nextWorkingDay,HttpStatus.BAD_REQUEST);
                    }
                } else {
                	nextWorkingDay.setErrorcode("400");
                	nextWorkingDay.setErrormessge("The after date is not a valid date");
                	nextWorkingDay.setInputdate(dateInput);
                	
                    return new ResponseEntity<>(nextWorkingDay,HttpStatus.BAD_REQUEST);
                }
            }
        } catch (Exception e) {
        	nextWorkingDay.setErrorcode("400");
        	nextWorkingDay.setErrormessge("The after date is not a valid date");
        	nextWorkingDay.setInputdate(dateInput);
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

/*
    @GetMapping("/addpublicholiday")
    public ResponseEntity<Void> savePublicHoliday(@RequestParam PublicHolidayRequest request) {
        try {
            String publicHolidayDate = request.getPublicHolidayDate();
            int result = nextWorkingDayInterface.save(publicHolidayDate);
            if (result > 0) {
                return new ResponseEntity<>(HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    */


    // Endpoint to get all public holiday dates
    @GetMapping("/publicholidays")
    public ResponseEntity<List<PublicHolidayDates>> getAllPublicHolidays() {
        try {
            List<PublicHolidayDates> publicHolidays = nextWorkingDayInterface.findAll();
            if (!publicHolidays.isEmpty()) {
                return new ResponseEntity<>(publicHolidays, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
        	e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    
    
    // Helper method to parse date in "YYYY-MM-DD" format
    private Date parseDate(String dateInput) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.setLenient(false);
            return dateFormat.parse(dateInput);
        } catch (ParseException e) {
            return null;
        }
    }

    // Helper method to format a Date object as "YYYY-MM-DD"
    private String formatDate(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return dateFormat.format(date);
    }


    
}
