package com.coopbank.nextworkingday.repository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.coopbank.nextworkingday.model.NextWorkingDay;
import com.coopbank.nextworkingday.model.PublicHolidayDates;

@Repository
public class NextWorkingDayRepository implements NextWorkingDayInterface {

  @Autowired
  private JdbcTemplate jdbcTemplate;

  static Logger logger = Logger.getLogger(NextWorkingDayRepository.class.getName());

 
  //next_working_day, next_working_day_name
  public NextWorkingDay nextworkingday(String dateInput) {
	  
	
	    String sql = "SELECT * FROM get_next_working_day(CAST(? AS date))";
	    	
	    logger.info(sql);   
		  try {
	    return jdbcTemplate.queryForObject(sql, new Object[]{dateInput}, (rs, rowNum) -> {
	        NextWorkingDay result = new NextWorkingDay();
	        result.setWorkingdate(rs.getString("next_working_day"));
	        result.setWorkingdatename(rs.getString("next_working_day_name").toUpperCase());
	        return result;
	    });
		  }catch(Exception eee)
		  {
			    logger.info(eee.getMessage());   
			  return null;
		  }
		
	}


public int save(String publicHolidayDate) {
    try {
        // Parse the string to a Date object with the expected format
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date parsedDate = dateFormat.parse(publicHolidayDate);
        Date sqlDate = new Date(parsedDate.getTime());

        // Insert the Date into the database
        int rowsAffected = jdbcTemplate.update("INSERT INTO public_holidays (holiday_date) VALUES(?)",
            new Object[] { sqlDate });

        return rowsAffected;
    } catch (ParseException e) {
      //  e.printStackTrace();
    	logger.info(e.getMessage());
        return -1; // Handle parsing error
    } catch (Exception eee) {
       // eee.printStackTrace();
    	logger.info(eee.getMessage());
        return -1; // Handle other exceptions
    }
}

public List<PublicHolidayDates> findAll() {
    String sql = "SELECT holiday_date FROM public_holidays";
    
    try {
        return jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(PublicHolidayDates.class));
    } catch (Exception e) {
        // Handle the exception, e.g., log it or throw a custom exception
    	e.printStackTrace();
        throw new RuntimeException("Failed to retrieve public holiday dates", e);
    }
}
}

