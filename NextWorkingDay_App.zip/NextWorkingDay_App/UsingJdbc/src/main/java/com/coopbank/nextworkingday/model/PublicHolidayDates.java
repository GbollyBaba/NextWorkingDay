package com.coopbank.nextworkingday.model;
public class PublicHolidayDates {
    private String holiday_date; // Match the field name to the database column

    public String getHoliday_date() {
        return holiday_date;
    }

    public void setHoliday_date(String holiday_date) {
        this.holiday_date = holiday_date;
    }

    // Other methods as needed
}
