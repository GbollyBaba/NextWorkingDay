package com.coopbank.nextworkingday.repository;

import java.util.List;

import com.coopbank.nextworkingday.model.NextWorkingDay;
import com.coopbank.nextworkingday.model.PublicHolidayDates;

public interface NextWorkingDayInterface {
	NextWorkingDay nextworkingday(String dateInput);
  int save(String publicholidaydate);
  List<PublicHolidayDates> findAll();

 
}
