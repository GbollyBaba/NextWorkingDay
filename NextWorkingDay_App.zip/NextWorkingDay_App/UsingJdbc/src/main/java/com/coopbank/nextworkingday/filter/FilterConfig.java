package com.coopbank.nextworkingday.filter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterConfig {

    @Bean
    public FilterRegistrationBean<HeaderHandlingFilter> headerHandlingFilter() {
        FilterRegistrationBean<HeaderHandlingFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new HeaderHandlingFilter());
        registrationBean.addUrlPatterns("/api"); // Specify the URL patterns to which the filter should apply
        return registrationBean;
    }
}
