package com.coopbank.nextworkingday.model;

public class PublicHolidayRequest {
private String publicHolidayDate;

public String getPublicHolidayDate() {
	return publicHolidayDate;
}

public void setPublicHolidayDate(String publicHolidayDate) {
	this.publicHolidayDate = publicHolidayDate;
}
}
