package com.coopbank.nextworkingday;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NextWorkingDay {

	public static void main(String[] args) {
		SpringApplication.run(NextWorkingDay.class, args);
	}

}
