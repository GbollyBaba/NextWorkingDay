package com.coopbank.nextworkingday.model;

public class NextWorkingDay {
	private  String  inputdate;
	private  String  workingdate;
	private  String  workingdatename;
	private  String  errorcode;
	private  String  errormessge;
	public String getWorkingdate() {
		return workingdate;
	}
	public void setWorkingdate(String workingdate) {
		this.workingdate = workingdate;
	}
	public String getWorkingdatename() {
		return workingdatename;
	}
	public void setWorkingdatename(String workingdatename) {
		this.workingdatename = workingdatename;
	}
	public String getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}
	public String getErrormessge() {
		return errormessge;
	}
	public void setErrormessge(String errormessge) {
		this.errormessge = errormessge;
	}
	public String getInputdate() {
		return inputdate;
	}
	public void setInputdate(String inputdate) {
		this.inputdate = inputdate;
	}
	

}
