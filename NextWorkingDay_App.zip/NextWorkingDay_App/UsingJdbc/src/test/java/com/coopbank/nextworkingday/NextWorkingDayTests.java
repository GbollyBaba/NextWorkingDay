package com.coopbank.nextworkingday;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Collections;

import org.junit.jupiter.api.Test;
//import e
import org.junit.jupiter.api.Test;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;
//@SpringBootTest
class NextWorkingDayTests {


	@Test
    public void testNextWorkingDayEndpoint() {
        // Create a RestTemplate
        RestTemplate restTemplate = new RestTemplate();

        // Set the request headers
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Basic dXNlcjpjNWYwZGRiOC1mNGI3LTRkYjAtYjI5Yy0zZDE5OTA0Njk2NGQ=");
        headers.set("Cookie", "JSESSIONID=908A8DB923EC15297FC78F35B79F241D");

        HttpEntity<String> entity = new HttpEntity<>(headers);

        // Make the GET request
        ResponseEntity<String> responseEntity = restTemplate.exchange(
                "https://localhost:8443/api/nextworkingday?dateInput=2022-12-24",
                HttpMethod.GET,
                entity,
                String.class
        );

        // Assert HTTP status code is 200
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

        // You can also assert other aspects of the response if needed.
        // For example, response body content, JSON parsing, etc.
    }

}
